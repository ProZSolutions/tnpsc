import 'package:flutter/material.dart';

class ExamPage extends StatefulWidget {
  @override
  _ExamPageState createState() => _ExamPageState();
}

class _ExamPageState extends State<ExamPage> {
   late int kishore;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child:SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              margin: EdgeInsets.all(15),
              child: ListView(
                children: <Widget>[
                  Card(
                    child:  InkWell(
                      splashColor: Colors.blue.withAlpha(30),
                      onTap: () {
                        print('Preliminary Checklist');
                      },
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.1,
                        child: Center(
                          child: ListTile(
                            leading: FlutterLogo(),
                            title: Text('Preliminary Checklist'),
                          ),
                        )
                      ),
                    )
                  ),
                  SizedBox(height: 5),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('Staff Attendance');
                        },
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('Staff Attendance'),
                              ),
                            )
                        ),
                      )
                  ),
                  SizedBox(height: 5),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('Hall List with Staff Allocation');
                        },
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('Hall List with Staff Allocation'),
                              ),
                            )
                        ),
                      )
                  ),
                  SizedBox(height: 5),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('Candidate Attendance');
                        },
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('Candidate Attendance'),
                              ),
                            )
                        ),
                      )
                  ),
                  SizedBox(height: 5),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('Malpractice Updates');
                        },
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('Malpractice Updates'),
                              ),
                            )
                        ),
                      )
                  ),
                  SizedBox(height: 5),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('Q&A Sheet Damage/Shortage');
                        },
                        child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('Q&A Sheet Damage/Shortage'),
                              ),
                            )
                        ),
                      )
                  ),
                ],
              ),
            )
          ],
        ),
      )
    );
  }
}
