import 'package:flutter/material.dart';
import 'package:tnpsc/login/login_page.dart';
import 'package:tnpsc/view/exam/alertbox.dart';

class MorePage extends StatefulWidget {
  const MorePage({Key? key}) : super(key: key);

  @override
  _MorePageState createState() => _MorePageState();
}

class _MorePageState extends State<MorePage> {
  int check1 = 0;
  int check2 = 0;
  int check3 = 0;
  bool checkedValue = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Center(
            child: Container(
              margin: EdgeInsets.only(left: 20,right: 20),
              child: Column(
                children: [
                  SizedBox(height: 20),
                  Card(
                      child:  InkWell(
                        splashColor: Colors.blue.withAlpha(30),
                        onTap: () {
                          print('User');
                        },
                        child: Container(
                            height: 80,
                            child: Center(
                              child: ListTile(
                                leading: FlutterLogo(),
                                title: Text('User name'),
                                subtitle: Text('samplename@gmail.com'),
                                trailing:IconButton(
                                  icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                                  onPressed: (){
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'My Profile',)));
                                  },
                                )
                              ),
                            )
                        ),
                      )
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height * 0.45,
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.white
                    ),
                    child: Column(
                      children: [
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.location_on_outlined,color: Colors.green[900]),
                            title: Text('Venue'),
                            trailing:IconButton(
                              icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Venue',)));
                              },
                            )
                          ),
                        ),
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.people_outline,color: Colors.green[900]),
                            title: Text('Assistant'),
                            trailing:IconButton(
                              icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Assistant',)));
                              },
                            )
                          ),
                        ),
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.people_outline,color: Colors.green[900]),
                            title: Text('Staff'),
                            trailing:IconButton(
                              icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Staff',)));
                              },
                            )
                          ),
                        ),
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.location_on_outlined,color: Colors.green[900]),
                            title: Text('Scribles'),
                            trailing:IconButton(
                              icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Scribles',)));
                              },
                            )
                          ),
                        ),
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.contact_page_outlined,color: Colors.green[900]),
                            title: Text('Contact'),
                            trailing:IconButton(
                              icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Scribles',)));
                              },
                            )
                          ),
                        ),
                        Center(
                          child: ListTile(
                            leading:Icon(Icons.notifications_none_outlined,color: Colors.green[900]),
                            title: Text('Notification'),
                            trailing:IconButton(
                             icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                              onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context) => NewPage( name:'Notification',)));
                              },
                            )
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.zero,
                    child: Card(
                        child:  InkWell(
                          splashColor: Colors.blue.withAlpha(30),
                          onTap: () {
                            print('User');
                          },
                          child: Container(
                              height: 60,
                              child: Center(
                                child: ListTile(
                                  leading:Icon(Icons.logout,color: Colors.green[900]),
                                  title: Text('Logout'),
                                  trailing:IconButton(
                                    icon:  Icon(Icons.arrow_forward_ios_outlined,size: 14,color: Colors.grey,),
                                    onPressed: (){
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
                                    },
                                  )
                                ),
                              ),
                          ),
                        )
                    ),
                  )
                ],
              ),
            )
        )
    );
  }
}

class NewPage extends StatelessWidget {
  const NewPage({
    Key? key,
    required this.name,
  }) : super(key: key);

  final String name;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.green[900],
          title: Text("${name}",),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: (){
              Navigator.pop(context);
            },
          ),
        ),
        body: Container(),
      ),
    );
  }
}
