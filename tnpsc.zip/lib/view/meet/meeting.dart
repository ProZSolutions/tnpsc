import 'package:flutter/material.dart';
import 'package:tnpsc/home/home_page.dart';
import 'package:tnpsc/theme/fonts.dart';
import 'package:tnpsc/theme/styles.dart';
import 'package:tnpsc/view/exam/alertbox.dart';
import 'package:tnpsc/view/exam/exam.dart';

class MeetingPage extends StatefulWidget {
  @override
  _MeetingPageState createState() => _MeetingPageState();
}

class _MeetingPageState extends State<MeetingPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: MediaQuery.of(context).size.height / 7,
              width: MediaQuery.of(context).size.width / 3.0,
              decoration: BoxDecoration(),
              child:Image.asset('assets/images/qr_image.png'),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.15),
            Padding(
              padding: EdgeInsets.all(10),
              child: Text('Welcome to Meeting',
                style: TextStyle(
                  fontSize: Styles.textSizTwenty,
                  fontWeight: FontSizeData.fontWeightValueLarge,
                ),),
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child: Text('Scan the QR code to register your attendance',
                style: TextStyle(
                  fontSize: Styles.textSizRegular,
                  color: Colors.grey
                ),),
            ),
            SizedBox(height: 20),
            Padding(
                padding: EdgeInsets.all(20),
                child: ButtonTheme(
                    height: MediaQuery.of(context).size.height * 0.06,
                    minWidth: MediaQuery.of(context).size.width * 0.9,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 1,
                      color: Colors.green[900],
                      onPressed: (){
                        setState(() {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => NewMeet()));
                          showDialog(
                            barrierColor: Colors.black26,
                            context: context,
                            builder: (context) {
                              return CustomAlertDialog(
                                title: "Thanks for attend the meeting.",
                                description: "Your attendance has been registered.",
                              );
                            },
                          );
                          // Navigator.pop(context);
                        }
                        );
                      },
                      child: Text("CLICK TO SCAN QR ",style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 18),),
                    )

                )
            ),
          ],
        ),
      )
    );
  }

}

class NewMeet extends StatefulWidget {

  @override
  _NewMeetState createState() => _NewMeetState();
}

class _NewMeetState extends State<NewMeet> {
  int check1 = 0;
  int check2 = 0;
  int check3 = 0;
  bool checkedValue = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[900],
        title: Text('Meeting'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: (){
            Navigator.pop(context);
          },
        ),
      ),
      body:  SafeArea(
          child: Center(
              child: Container(
                margin: EdgeInsets.only(left: 20,right: 20),
                child: Column(
                  children: [
                    SizedBox(height: 20),
                    Card(
                        child:  InkWell(
                          splashColor: Colors.blue.withAlpha(30),
                          onTap: () {
                            showDialog(
                              barrierColor: Colors.black26,
                              context: context,
                              builder: (context) {
                                return CustomAlertDialog(
                                  title: "Question box scanning has been ",
                                  description: "successfully verified.",
                                );
                              },
                            );
                            check1 = 1;
                            print('Scan Question Box');
                          },
                          child: Container(
                              height: MediaQuery.of(context).size.height * 0.1,
                              child: Center(
                                child: ListTile(
                                  leading: FlutterLogo(),
                                  title: Text('Scan Question Box'),
                                  trailing:(check1 == 1)? Icon(Icons.check,color: Colors.green,): Icon(Icons.check,color: Colors.white,),
                                ),
                              )
                          ),
                        )
                    ),
                    Card(
                        child:  InkWell(
                          splashColor: Colors.blue.withAlpha(30),
                          onTap: () {
                            showDialog(
                              barrierColor: Colors.black26,
                              context: context,
                              builder: (context) {
                                return CustomAlertDialog(
                                  title: "Answer sheet box scanning has",
                                  description: " been successfully verified.",
                                );
                              },
                            );
                            check2 = 1;
                            print('Scan Answer Sheet Box');
                          },
                          child: Container(
                              height: MediaQuery.of(context).size.height * 0.1,
                              child: Center(
                                child: ListTile(
                                  leading: FlutterLogo(),
                                  title: Text('Scan Answer Sheet Box'),
                                  trailing: (check2 == 1)? Icon(Icons.check,color: Colors.green,): Icon(Icons.check,color: Colors.white,),
                                ),
                              )
                          ),
                        )
                    ),
                    Card(
                        child:  InkWell(
                          splashColor: Colors.blue.withAlpha(30),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => getAcknowledgement()));
                            check3 = 1;
                            print('Meeting Acknowledgement');
                          },
                          child: Container(
                              height: MediaQuery.of(context).size.height * 0.1,
                              child: Center(
                                child: ListTile(
                                  leading: FlutterLogo(),
                                  title: Text('Meeting Acknowledgement'),
                                  trailing: (check3 == 1)? Icon(Icons.check,color: Colors.green,): Icon(Icons.check,color: Colors.white,),
                                ),
                              )
                          ),
                        )
                    ),
                    Expanded(
                      child: Align(
                          alignment: FractionalOffset.bottomCenter,
                          child: ButtonTheme(
                              height: MediaQuery.of(context).size.height * 0.06,
                              minWidth: MediaQuery.of(context).size.width * 0.9,
                              child: RaisedButton(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                elevation: 1,
                                color: (check3 == 1 ) ? Colors.green[900] : Colors.grey,
                                onPressed: (check3 == 1) ? (){
                                  setState(() {
                                    print('Acknowledgement');
                                    Navigator.pop(context);
                                    // Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                  }
                                  );
                                }
                                    :(){
                                  setState(() {
                                    print('Not Acknowledgement');
                                    // Navigator.pop(context);
                                    // Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                  }
                                  );
                                },
                                child: Text("FINISH MEETING",style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 18),),
                              )
                          )
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              )
          )
      ),
    );
  }
  Widget getAcknowledgement(){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.green[900],
            title: Text('Meeting Acknowlwdgement'),
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: (){
                Navigator.pop(context);
              },
            ),
          ),
          body: Container(
            color: Colors.grey[100],
            child: Center(
              child: Column(
                children: [
                  CheckboxListTile(
                    title: Text('Received Appoinment Order'),
                    value: checkedValue,
                    activeColor: Colors.green[900],
                    onChanged: (newValue) {
                      setState(() {
                        checkedValue = newValue!;
                      });
                    },
                    controlAffinity: ListTileControlAffinity.leading,  //  <-- leading Checkbox
                  ),
                  CheckboxListTile(
                    title: Text('Received Packet containing attendance sheet -cum-hall-sketch'),
                    value: checkedValue,
                    activeColor: Colors.green[900],
                    onChanged: (newValue) {
                      setState(() {
                        checkedValue = newValue!;
                      });
                    },
                    controlAffinity: ListTileControlAffinity.leading,  //  <-- leading Checkbox
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 20,left: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:[
                        Text('Received Rs.',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w400),),
                        Container(
                          margin: EdgeInsets.only(left: 10),
                          height: 50,
                          width : 150,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey),
                              color: Colors.white
                          ),
                          child:TextFormField(
                            enabled: false,
                            textAlign: TextAlign.center,
                            decoration: InputDecoration(
                              alignLabelWithHint: true,
                              labelText: '25,000/-',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Align(
                        alignment: FractionalOffset.bottomCenter,
                        child: ButtonTheme(
                            height: MediaQuery.of(context).size.height * 0.06,
                            minWidth: MediaQuery.of(context).size.width * 0.9,
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                              elevation: 1,
                              color: Colors.green[900],
                              onPressed:(){
                                setState(() {
                                  print('Metting check page');
                                  Navigator.pop(context);
                                  // Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                                }
                                );
                              },
                              child: Text("Done",style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 18),),
                            )
                        )
                    ),
                  ),
                  SizedBox(height: 50),
                ],
              ),
            ),
          )
      ),
    );
  }
}

