import 'package:flutter/material.dart';
import 'package:tnpsc/home/home_page.dart';
import 'package:tnpsc/theme/fonts.dart';
import 'package:tnpsc/theme/styles.dart';

class LoginPage extends StatefulWidget {
   @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late String _userName;
  late String _password;
  bool checkedValue = false;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child:IntrinsicHeight(
          child: Column(
            children: <Widget>[
              getLogo(),
              getLoginForm(),
              Padding(
                padding: EdgeInsets.only(left: 20,right: 20,top: 20),
                child: ButtonTheme(
                  height: MediaQuery.of(context).size.height * 0.06,
                minWidth: MediaQuery.of(context).size.width * 0.9,
                 child: RaisedButton(
                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                   elevation: 1,
                    color: Colors.green[900],
                    onPressed: (){
                      setState(() {
                        if(!_formKey.currentState!.validate()) {
                          return;
                        }
                        _formKey.currentState!.save();
                        print(_userName);
                        print(_password);
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
                      }
                      );
                    },
                    child: Text("LOGIN",style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 18),),
                  )

              )
              ),
              Padding(
                padding: EdgeInsets.zero,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children:[
                    Expanded(
                      child: CheckboxListTile(
                        title: Text('Remember me'),
                        value: checkedValue,
                        activeColor: Colors.green[900],
                        onChanged: (newValue) {
                          setState(() {
                            checkedValue = newValue!;
                          });
                        },
                        controlAffinity: ListTileControlAffinity.leading,  //  <-- leading Checkbox
                      ),),
                    TextButton(
                      onPressed: () {},
                      child: Text('Forgot Password?',style: TextStyle(color: Colors.green[900]),),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      )
    );
  }

  Widget getLogo(){
    return Column(
      children: [
        Container(
          height: MediaQuery.of(context).size.height / 7,
          width: MediaQuery.of(context).size.width / 3.0,
          decoration: BoxDecoration(),
          child:Image.asset('assets/images/logo.jpg'),),
        Padding(
          padding: EdgeInsets.zero,
          child: Text('TNPSC',
            style: TextStyle(
              fontSize: Styles.textSizTwenty,
              fontWeight: FontSizeData.fontWeightValueLarge,
            ),),
        )
      ],
    );
  }

  Widget getLoginForm(){
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: IntrinsicHeight(
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('Login To Your Account',
                      style: TextStyle(
                        fontSize: Styles.textSizeSeventeen,
                        fontWeight: FontSizeData.fontWeightValueLarge,
                      ),
                    ),
                  ),
                ],
              ),
              Card(
                margin: EdgeInsets.all(20),
                elevation: 1,
                child: Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: TextFormField(
                    obscureText: false,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'User Name is Empty';
                      }
                      else{
                        return null;}
                    },
                    onSaved: (value) {
                      _userName = value!;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      floatingLabelBehavior: FloatingLabelBehavior.never,
                      labelText: 'User Name',
                    ),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.only(top: 10,left: 15,right: 15),
                elevation: 1,
                child: Padding(
                  padding: EdgeInsets.only(left: 20),
                  child: TextFormField(
                    obscureText: true,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Password is Empty';
                      }
                      else{
                        return null;}
                    },
                    onSaved: (value) {
                      _password = value!;
                    },
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      errorBorder: InputBorder.none,
                      disabledBorder: InputBorder.none,
                      labelText: 'Password',
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

}
