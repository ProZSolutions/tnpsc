import 'package:flutter/material.dart';
import 'package:tnpsc/view/exam/exam.dart';
import 'package:tnpsc/view/meet/meeting.dart';
import 'package:tnpsc/view/more/more.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  int currentIndex = 0;

  final Screens =[
    Center(child: Text("Page 1") ),
    MeetingPage(),
    ExamPage(),
    MorePage(),
  ];


  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 4,
        child: Scaffold(
          appBar: AppBar(
            elevation: (currentIndex == 0) ? 0 : 2,
            backgroundColor: (currentIndex == 0) ? Colors.white : Colors.green[900],
            title: Text((currentIndex == 0) ? ''
                : (currentIndex == 1) ? 'Meet'
                : (currentIndex == 2) ? 'Exam'
                : 'More'),
          ),
          body: Screens[currentIndex],
          bottomNavigationBar: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: currentIndex,
            unselectedItemColor: Colors.grey,
            showUnselectedLabels: true,
            onTap: (index) => setState(() => currentIndex =index),
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today_sharp),
                label: 'Meet',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.list_alt_rounded),
                label: 'Exam',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.more_vert_rounded),
                label: 'More',
              ),
            ],
            selectedItemColor: Colors.green[900],
          ),
        ),
    );
  }
}